<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // Adjust for production

// Database connection details
$host = 'localhost';
$dbname = 'perthrel_tricky';
$username = 'perthrel_perthrel'; // Replace with your cPanel MySQL username
$password = 'u84if;4c#pzL'; // Replace with your cPanel MySQL password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch 500000 random rows from the words table
    $limit = 17000;
    $stmt = $pdo->query("SELECT `COL 1`, `COL 2` FROM words ORDER BY RAND() LIMIT $limit");
    $words = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Format as [word, definition] pairs
    $formattedWords = array_map(function($row) {
        return [$row['COL 1'], $row['COL 2']];
    }, $words);

    echo json_encode($formattedWords);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>