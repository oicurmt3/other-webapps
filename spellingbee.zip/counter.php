<?php
$counter_file = "counter.txt";

// Read current count
$count = (int)file_get_contents($counter_file);

// Increment count
$count++;

// Save new count
file_put_contents($counter_file, $count);

// Return count as plain text
header('Content-Type: text/plain');
echo $count;
?>