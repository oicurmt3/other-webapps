// Get references to DOM elements
const gameIcons = document.getElementById('gameIcons');
const choiceIcons = document.getElementById('choiceIcons');
const resetButton = document.getElementById('resetButton');
const showIconsButton = document.getElementById('showIconsButton');
const stats = document.getElementById('stats');

const numIconsInput = document.getElementById('numIcons');
const guessingModeSelect = document.getElementById('guessingMode');
const feedbackModeSelect = document.getElementById('feedbackMode');
const displayTimeModeSelect = document.getElementById('displayTimeMode');
const showHistoryCheckbox = document.getElementById('showHistory');
const scoreBoard = document.getElementById('scoreBoard');
const topScoresList = document.getElementById('topScores');
const guessHistoryDiv = document.getElementById('guessHistory');

// Icons available for the game
const icons = [
    'favorite', 'home', 'settings', 'delete', 'search',
    'alarm', 'event', 'grade', 'info', 'lock',
    'mail', 'person', 'pets', 'schedule', 'school',
    'star', 'work', 'thumb_up', 'visibility', 'trending_up'
];

// Game variables
let gameSequence = [];
let playerSequence = [];
let tries = 0;
let startTime;
let totalTimeTaken = 0;
let iconDisplayTime = 1500; // Initial display time in milliseconds
let guessHistory = [];
let gameStarted = false;

// Load top scores from localStorage
let topScores = JSON.parse(localStorage.getItem('topScores')) || [];

// Display top scores
function displayTopScores() {
    topScoresList.innerHTML = '';
    // Sort scores from lowest to highest
    topScores.sort((a, b) => a.score - b.score);
    topScores.slice(0, 5).forEach((entry) => {
        const li = document.createElement('li');
        li.textContent = `Score: ${entry.score}, Tries: ${entry.tries}, Time: ${entry.time}s`;
        topScoresList.appendChild(li);
    });
}

// Save top scores to localStorage
function saveTopScores() {
    localStorage.setItem('topScores', JSON.stringify(topScores));
}

// Function to shuffle an array
function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

// Create a game icon element
function createGameIcon() {
    const icon = document.createElement('div');
    icon.className = 'game-icon';
    const span = document.createElement('span');
    span.className = 'material-icons';
    span.textContent = 'help_outline';
    icon.appendChild(span);
    return icon;
}

// Create a choice button element
function createChoiceButton(iconName) {
    const button = document.createElement('button');
    button.className = 'choice-button';
    button.setAttribute('aria-label', iconName);
    const icon = document.createElement('span');
    icon.className = 'material-icons';
    icon.textContent = iconName;
    button.appendChild(icon);
    return button;
}

// Generate the game sequence
function generateGameSequence() {
    gameSequence = [];
    const shuffledIcons = [...icons];
    shuffleArray(shuffledIcons);
    const numIcons = parseInt(numIconsInput.value);
    for (let i = 0; i < numIcons; i++) {
        gameSequence.push(shuffledIcons[i]);
    }
}

// Display the game icons
function displayGameIcons() {
    gameIcons.innerHTML = ''; // Clear previous icons
    const numIcons = parseInt(numIconsInput.value);

    // Determine the row configurations based on the number of icons
    let rowConfigs = [];
    switch (numIcons) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
            rowConfigs = [numIcons];
            break;
        case 6:
            rowConfigs = [3, 3];
            break;
        case 7:
            rowConfigs = [4, 3];
            break;
        case 8:
            rowConfigs = [4, 4];
            break;
        case 9:
            rowConfigs = [5, 4];
            break;
        case 10:
            rowConfigs = [5, 5];
            break;
        default:
            rowConfigs = [numIcons];
    }

    let iconIndex = 0;
    rowConfigs.forEach((iconsInRow) => {
        const rowDiv = document.createElement('div');
        rowDiv.className = 'icon-row';
        for (let i = 0; i < iconsInRow; i++) {
            const iconElement = createGameIcon();
            rowDiv.appendChild(iconElement);
            iconIndex++;
        }
        gameIcons.appendChild(rowDiv);
    });
}

// Reset game icons to initial state
function resetGameIcons() {
    gameIcons.querySelectorAll('.game-icon').forEach((icon) => {
        icon.classList.remove('correct', 'incorrect', 'partial');
        icon.querySelector('.material-icons').textContent = 'help_outline';
    });
}

// Show the game icons sequence
function showGameIcons() {
    resetGameIcons(); // Reset icons before showing

    startTime = new Date(); // Start the timer for this attempt

    // Display the icons
    let iconIndex = 0;
    gameSequence.forEach((iconName) => {
        const rowConfigs = getRowConfigs();
        let rowIndex = 0;
        let iconPosition = iconIndex;
        for (let i = 0; i < rowConfigs.length; i++) {
            if (iconPosition < rowConfigs[i]) {
                rowIndex = i;
                break;
            } else {
                iconPosition -= rowConfigs[i];
            }
        }
        const rowDiv = gameIcons.children[rowIndex];
        const icon = rowDiv.children[iconPosition].querySelector('.material-icons');
        icon.textContent = iconName;
        iconIndex++;
    });

    // Hide icons after a delay
    setTimeout(() => {
        gameIcons.querySelectorAll('.material-icons').forEach((icon) => {
            icon.textContent = 'help_outline';
        });

        // Enable choice buttons after icons are hidden
        choiceIcons.querySelectorAll('.choice-button').forEach((button) => {
            button.disabled = false;
        });
    }, iconDisplayTime);

    // Disable choice buttons while icons are displayed
    choiceIcons.querySelectorAll('.choice-button').forEach((button) => {
        button.disabled = true;
    });

    // Reset player sequence
    playerSequence = [];
}

// Helper function to get row configurations
function getRowConfigs() {
    const numIcons = parseInt(numIconsInput.value);
    let rowConfigs = [];
    switch (numIcons) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
            rowConfigs = [numIcons];
            break;
        case 6:
            rowConfigs = [3, 3];
            break;
        case 7:
            rowConfigs = [4, 3];
            break;
        case 8:
            rowConfigs = [4, 4];
            break;
        case 9:
            rowConfigs = [5, 4];
            break;
        case 10:
            rowConfigs = [5, 5];
            break;
        default:
            rowConfigs = [numIcons];
    }
    return rowConfigs;
}

// Display the choice icons
function displayChoiceIcons() {
    choiceIcons.innerHTML = '';
    icons.forEach((iconName) => {
        const button = createChoiceButton(iconName);
        button.addEventListener('click', () => selectIcon(iconName, button));
        choiceIcons.appendChild(button);
    });
}

// Disable options once the game starts
function disableOptions() {
    numIconsInput.disabled = true;
    guessingModeSelect.disabled = true;
    feedbackModeSelect.disabled = true;
    displayTimeModeSelect.disabled = true;
    showHistoryCheckbox.disabled = true;
}

// Enable options when resetting the game
function enableOptions() {
    numIconsInput.disabled = false;
    guessingModeSelect.disabled = false;
    feedbackModeSelect.disabled = false;
    displayTimeModeSelect.disabled = false;
    showHistoryCheckbox.disabled = false;
}

// Handle the selection of an icon
function selectIcon(iconName, button) {
    if (playerSequence.length >= gameSequence.length) {
        return; // Prevent additional selections
    }
    playerSequence.push({ iconName, button });
    button.disabled = true; // Disable the selected button

    const guessingMode = guessingModeSelect.value;

    const index = playerSequence.length - 1;

    // Update the game icon with the chosen icon
    const rowConfigs = getRowConfigs();
    let rowIndex = 0;
    let iconPosition = index;
    for (let i = 0; i < rowConfigs.length; i++) {
        if (iconPosition < rowConfigs[i]) {
            rowIndex = i;
            break;
        } else {
            iconPosition -= rowConfigs[i];
        }
    }

    const rowDiv = gameIcons.children[rowIndex];
    const gameIcon = rowDiv.children[iconPosition];
    const icon = gameIcon.querySelector('.material-icons');
    icon.textContent = iconName;

    if (guessingMode === 'incremental') {
        provideFeedback(index);
    }

    if (playerSequence.length === gameSequence.length) {
        // Disable all choice buttons
        choiceIcons.querySelectorAll('.choice-button').forEach((btn) => {
            btn.disabled = true;
        });

        if (guessingMode === 'full') {
            // Provide feedback after full sequence is guessed
            provideFeedback();
        }
        checkSequence();
    }
}

// Provide feedback on the player's guesses
function provideFeedback(index = null) {
    const feedbackMode = feedbackModeSelect.value;
    if (index !== null) {
        // Provide feedback for a single icon
        const rowConfigs = getRowConfigs();
        let rowIndex = 0;
        let iconPosition = index;
        for (let i = 0; i < rowConfigs.length; i++) {
            if (iconPosition < rowConfigs[i]) {
                rowIndex = i;
                break;
            } else {
                iconPosition -= rowConfigs[i];
            }
        }

        const rowDiv = gameIcons.children[rowIndex];
        const gameIcon = rowDiv.children[iconPosition];
        const guessedIcon = playerSequence[index].iconName;
        if (guessedIcon === gameSequence[index]) {
            gameIcon.classList.add('correct');
        } else if (
            feedbackMode === 'red-green-orange' &&
            gameSequence.includes(guessedIcon)
        ) {
            gameIcon.classList.add('partial');
        } else {
            gameIcon.classList.add('incorrect');
        }
    } else {
        // Provide feedback for the full sequence
        for (let i = 0; i < gameSequence.length; i++) {
            const rowConfigs = getRowConfigs();
            let rowIndex = 0;
            let iconPosition = i;
            for (let j = 0; j < rowConfigs.length; j++) {
                if (iconPosition < rowConfigs[j]) {
                    rowIndex = j;
                    break;
                } else {
                    iconPosition -= rowConfigs[j];
                }
            }

            const rowDiv = gameIcons.children[rowIndex];
            const gameIcon = rowDiv.children[iconPosition];
            const guessedIcon = playerSequence[i].iconName;
            if (guessedIcon === gameSequence[i]) {
                gameIcon.classList.add('correct');
            } else if (
                feedbackMode === 'red-green-orange' &&
                gameSequence.includes(guessedIcon)
            ) {
                gameIcon.classList.add('partial');
            } else {
                gameIcon.classList.add('incorrect');
            }
        }
    }
}

// Check if the player's sequence matches the game sequence
function checkSequence() {
    tries++;
    const endTime = new Date();
    const timeTakenSeconds = (endTime - startTime) / 1000;
    totalTimeTaken += timeTakenSeconds;
    const timeTaken = totalTimeTaken.toFixed(2);
    const isCorrect = playerSequence.every(
        ({ iconName }, index) => iconName === gameSequence[index]
    );

    // Save guess history if enabled
    if (showHistoryCheckbox.checked) {
        saveGuessHistory();
    }

    if (isCorrect) {
        stats.textContent = `🎉 You won in ${tries} tries and ${timeTaken}s.`;

        // Calculate score
        const scoreValue = (tries * totalTimeTaken).toFixed(2);
        stats.textContent += ` Your score: ${scoreValue}`;

        // Save to top scores
        topScores.push({ score: parseFloat(scoreValue), tries, time: timeTaken });
        saveTopScores();
        displayTopScores();

        showIconsButton.disabled = true;

        // Reset icon display time
        iconDisplayTime = 1500;
    } else {
        stats.textContent = `❌ Incorrect. Tries: ${tries}. Try again.`;

        // Adjust icon display time if decreasing
        if (displayTimeModeSelect.value === 'decrease') {
            iconDisplayTime = Math.max(500, iconDisplayTime - 200); // Decrease by 200ms, min 500ms
        }
    }

    // Enable Show Icons button for next attempt
    showIconsButton.disabled = false;

    // Reset player sequence for the next turn
    playerSequence = [];
}

// Save the player's guess history
function saveGuessHistory() {
    const guess = playerSequence.map((item, index) => {
        const isCorrect = item.iconName === gameSequence[index];
        const isPartial =
            feedbackModeSelect.value === 'red-green-orange' &&
            gameSequence.includes(item.iconName) &&
            !isCorrect;
        return {
            iconName: item.iconName,
            status: isCorrect ? 'correct' : isPartial ? 'partial' : 'incorrect',
        };
    });
    guessHistory.push(guess);
    if (showHistoryCheckbox.checked) {
        displayGuessHistory();
    }
}

// Display the guess history
function displayGuessHistory() {
    if (!showHistoryCheckbox.checked) {
        guessHistoryDiv.style.display = 'none';
        return;
    }
    guessHistoryDiv.style.display = 'block';
    guessHistoryDiv.innerHTML = '<h2>Guess History</h2>';
    guessHistory.forEach((guess, i) => {
        const guessDiv = document.createElement('div');
        guessDiv.className = 'guess';
        guess.forEach((item) => {
            const gameIcon = document.createElement('div');
            gameIcon.className = `game-icon ${item.status}`;
            const iconSpan = document.createElement('span');
            iconSpan.className = 'material-icons';
            iconSpan.textContent = item.iconName;
            gameIcon.appendChild(iconSpan);
            guessDiv.appendChild(gameIcon);
        });
        guessHistoryDiv.appendChild(guessDiv);
    });
}

// Reset the game to its initial state
function resetGame() {
    if (gameStarted && !confirm('Are you sure you want to reset the game? Your progress will be lost.')) {
        return;
    }
    generateGameSequence();
    displayGameIcons();
    displayChoiceIcons();
    playerSequence = [];
    tries = 0;
    totalTimeTaken = 0;
    stats.textContent = '';
    showIconsButton.disabled = false;
    guessHistory = [];
    guessHistoryDiv.innerHTML = '';
    guessHistoryDiv.style.display = showHistoryCheckbox.checked ? 'block' : 'none';
    gameStarted = false;
    iconDisplayTime = 1500; // Reset icon display time

    resetGameIcons(); // Reset game icons to initial state

    enableOptions(); // Enable options
}

// Event listener for Reset Game button
resetButton.addEventListener('click', () => {
    resetGame();
});

// Event listener for Show Icons button
showIconsButton.addEventListener('click', () => {
    if (!gameStarted) {
        generateGameSequence();
        displayGameIcons();
        displayChoiceIcons();
        resetGameIcons();
        playerSequence = [];
        tries = 0;
        totalTimeTaken = 0;
        stats.textContent = '';
        guessHistory = [];
        guessHistoryDiv.innerHTML = '';
        gameStarted = true;

        disableOptions(); // Disable options after game starts
    } else {
        resetGameIcons(); // Reset game icons when Show Icons is clicked
    }
    showGameIcons();

    // Disable Show Icons button after it's clicked
    showIconsButton.disabled = true;
});

// Event listener for the history checkbox
showHistoryCheckbox.addEventListener('change', () => {
    if (showHistoryCheckbox.checked) {
        displayGuessHistory();
    } else {
        guessHistoryDiv.style.display = 'none';
    }
});

// Update game icons display when the number of icons changes
numIconsInput.addEventListener('change', () => {
    if (!gameStarted) {
        displayGameIcons();
    }
});

// Initial setup
displayGameIcons();
displayChoiceIcons();
displayTopScores();