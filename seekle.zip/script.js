// Get references to DOM elements
const choiceIcons = document.getElementById('choiceIcons');
const resetButton = document.getElementById('resetButton');
const startButton = document.getElementById('startButton');
const stats = document.getElementById('stats');

const sequenceLengthInput = document.getElementById('sequenceLength');
const feedbackModeSelect = document.getElementById('feedbackMode');
const showHistoryCheckbox = document.getElementById('showHistory');
const scoreBoard = document.getElementById('scoreBoard');
const topScoresList = document.getElementById('topScores');
const guessHistoryDiv = document.getElementById('guessHistory');

// Icons available for the game
const icons = [
    'favorite', 'home', 'settings', 'delete', 'search',
    'alarm', 'event', 'grade', 'info', 'lock',
    'mail', 'person', 'pets', 'schedule', 'school',
    'star', 'work', 'thumb_up', 'visibility', 'trending_up',
    'timeline', 'build', 'camera', 'edit', 'explore',
    'face', 'gavel', 'language', 'motorcycle', 'public'
];

// Game variables
let gameSequence = [];
let playerSequence = [];
let currentLevel = 1;
let tries = 0;
let startTime;
let totalTimeTaken = 0;
let iconDisplayTime = 1000; // Initial display time in milliseconds
let guessHistory = [];
let gameStarted = false;

// Load top scores from localStorage
let topScores = JSON.parse(localStorage.getItem('topScores')) || [];

// Display top scores
function displayTopScores() {
    topScoresList.innerHTML = '';
    topScores.sort((a, b) => b.score - a.score);
    topScores.slice(0, 5).forEach((entry) => {
        const li = document.createElement('li');
        li.textContent = `Score: ${entry.score}, Level: ${entry.level}, Time: ${entry.time}s`;
        topScoresList.appendChild(li);
    });
}

// Save top scores to localStorage
function saveTopScores() {
    localStorage.setItem('topScores', JSON.stringify(topScores));
}

// Function to shuffle an array
function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

// Create a choice button element
function createChoiceButton(iconName, index) {
    const button = document.createElement('button');
    button.className = 'choice-button';
    button.setAttribute('data-index', index);
    button.setAttribute('aria-label', iconName);
    const icon = document.createElement('span');
    icon.className = 'material-icons';
    icon.textContent = iconName;
    button.appendChild(icon);
    return button;
}

// Generate the game sequence
function generateGameSequence() {
    gameSequence = [];
    const shuffledIcons = [...icons];
    shuffleArray(shuffledIcons);
    const sequenceLength = Math.min(currentLevel + 3, 30); // Increase sequence length with level, max 30
    for (let i = 0; i < sequenceLength; i++) {
        gameSequence.push(Math.floor(Math.random() * 30)); // Random index from 0 to 29
    }
}

// Display the choice icons
function displayChoiceIcons() {
    choiceIcons.innerHTML = '';
    icons.forEach((iconName, index) => {
        const button = createChoiceButton(iconName, index);
        button.addEventListener('click', () => selectIcon(index));
        choiceIcons.appendChild(button);
    });
}

// Disable options once the game starts
function disableOptions() {
    sequenceLengthInput.disabled = true;
    feedbackModeSelect.disabled = true;
    showHistoryCheckbox.disabled = true;
}

// Enable options when resetting the game
function enableOptions() {
    sequenceLengthInput.disabled = false;
    feedbackModeSelect.disabled = false;
    showHistoryCheckbox.disabled = false;
}

// Flash the sequence on the grid
async function flashSequence() {
    for (const index of gameSequence) {
        const button = choiceIcons.children[index];
        button.classList.add('flashing');
        await new Promise(resolve => setTimeout(resolve, iconDisplayTime));
        button.classList.remove('flashing');
        await new Promise(resolve => setTimeout(resolve, 200)); // Pause between flashes
    }
}

// Handle the selection of an icon
function selectIcon(index) {
    if (playerSequence.length >= gameSequence.length) {
        return; // Prevent additional selections
    }
    playerSequence.push(index);
    const button = choiceIcons.children[index];
    button.classList.add('selected');

    if (playerSequence.length === gameSequence.length) {
        checkSequence();
    }
}

// Provide feedback on the player's guesses
function provideFeedback() {
    const feedbackMode = feedbackModeSelect.value;
    playerSequence.forEach((guessedIndex, i) => {
        const button = choiceIcons.children[guessedIndex];
        if (guessedIndex === gameSequence[i]) {
            button.classList.add('correct');
        } else if (feedbackMode === 'red-green-orange' && gameSequence.includes(guessedIndex)) {
            button.classList.add('partial');
        } else {
            button.classList.add('incorrect');
        }
    });
}

// Check if the player's sequence matches the game sequence
function checkSequence() {
    tries++;
    const endTime = new Date();
    const timeTakenSeconds = (endTime - startTime) / 1000;
    totalTimeTaken += timeTakenSeconds;
    const timeTaken = totalTimeTaken.toFixed(2);
    const isCorrect = playerSequence.every(
        (index, i) => index === gameSequence[i]
    );

    provideFeedback();

    // Save guess history if enabled
    if (showHistoryCheckbox.checked) {
        saveGuessHistory();
    }

    if (isCorrect) {
        stats.textContent = `🎉 Level ${currentLevel} completed in ${tries} tries and ${timeTaken}s.`;

        // Calculate score
        const scoreValue = Math.round((currentLevel * 1000) / (tries * totalTimeTaken));
        stats.textContent += ` Score: ${scoreValue}`;

        // Save to top scores
        topScores.push({ score: scoreValue, level: currentLevel, time: timeTaken });
        saveTopScores();
        displayTopScores();

        currentLevel++;
        startButton.textContent = 'Next Level';
        startButton.disabled = false;

        // Decrease display time for next level
        iconDisplayTime = Math.max(200, iconDisplayTime - 100);
    } else {
        stats.textContent = `❌ Incorrect. Tries: ${tries}. Try again.`;
        startButton.textContent = 'Retry Level';
        startButton.disabled = false;
    }

    // Reset player sequence for the next turn
    playerSequence = [];
}

// Save the player's guess history
function saveGuessHistory() {
    const guess = playerSequence.map((index, i) => {
        const isCorrect = index === gameSequence[i];
        const isPartial = feedbackModeSelect.value === 'red-green-orange' && 
                          gameSequence.includes(index) && !isCorrect;
        return {
            iconName: icons[index],
            status: isCorrect ? 'correct' : isPartial ? 'partial' : 'incorrect',
        };
    });
    guessHistory.push(guess);
    if (showHistoryCheckbox.checked) {
        displayGuessHistory();
    }
}

// Display the guess history
function displayGuessHistory() {
    if (!showHistoryCheckbox.checked) {
        guessHistoryDiv.style.display = 'none';
        return;
    }
    guessHistoryDiv.style.display = 'block';
    guessHistoryDiv.innerHTML = '<h2>Guess History</h2>';
    guessHistory.forEach((guess, i) => {
        const guessDiv = document.createElement('div');
        guessDiv.className = 'guess';
        guess.forEach((item) => {
            const gameIcon = document.createElement('div');
            gameIcon.className = `game-icon ${item.status}`;
            const iconSpan = document.createElement('span');
            iconSpan.className = 'material-icons';
            iconSpan.textContent = item.iconName;
            gameIcon.appendChild(iconSpan);
            guessDiv.appendChild(gameIcon);
        });
        guessHistoryDiv.appendChild(guessDiv);
    });
}

// Reset the game to its initial state
function resetGame() {
    if (gameStarted && !confirm('Are you sure you want to reset the game? Your progress will be lost.')) {
        return;
    }
    currentLevel = 1;
    playerSequence = [];
    tries = 0;
    totalTimeTaken = 0;
    stats.textContent = '';
    guessHistory = [];
    guessHistoryDiv.innerHTML = '';
    guessHistoryDiv.style.display = showHistoryCheckbox.checked ? 'block' : 'none';
    gameStarted = false;
    iconDisplayTime = 1000; // Reset icon display time

    startButton.textContent = 'Start Game';
    startButton.disabled = false;

    displayChoiceIcons(); // Reset choice icons
    enableOptions(); // Enable options
}

// Start the game or next level
async function startGame() {
    generateGameSequence();
    displayChoiceIcons();
    playerSequence = [];
    tries = 0;
    startTime = new Date();
    stats.textContent = '';
    gameStarted = true;

    disableOptions(); // Disable options after game starts
    startButton.disabled = true;

    // Clear previous feedback
    choiceIcons.querySelectorAll('.choice-button').forEach(button => {
        button.classList.remove('correct', 'incorrect', 'partial', 'selected');
    });

    await flashSequence();
}

// Event listener for Reset Game button
resetButton.addEventListener('click', resetGame);

// Event listener for Start Game / Next Level button
startButton.addEventListener('click', startGame);

// Event listener for the history checkbox
showHistoryCheckbox.addEventListener('change', () => {
    if (showHistoryCheckbox.checked) {
        displayGuessHistory();
    } else {
        guessHistoryDiv.style.display = 'none';
    }
});

// Initial setup
displayChoiceIcons();
displayTopScores();