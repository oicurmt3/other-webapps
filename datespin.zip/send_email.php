<?php
header('Content-Type: application/json');

// Get the POST data from the fetch request
$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['name']) || !isset($data['contact']) || !isset($data['dinner']) || !isset($data['activity'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid data received']);
    exit;
}

$name = htmlspecialchars($data['name']);
$contact = htmlspecialchars($data['contact']);
$dinner = htmlspecialchars($data['dinner']);
$activity = htmlspecialchars($data['activity']);

// Email configuration
$to = 'pjeaje@gmail.com'; // Pete's email address
$subject = "Date night with $name and Pete";
$body = "Hi Pete, I'm $name.\n\nI'd love to come over and let you cook me $dinner for dinner one night, we could play some $activity together too!\n\nYou can reach me on $contact. I'm looking forward to hearing from you. Don't let me down!";
$headers = "From: $name <no-reply@sandgroper.net>\r\n"; // Updated sender name
$headers .= "Reply-To: $contact\r\n";

// Attempt to send the email
if (mail($to, $subject, $body, $headers)) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to send email']);
}
?>