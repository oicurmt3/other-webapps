/* script.js */

// Dice configurations
const diceConfigs = [
    'aaafrs', 'aaeeee', 'aafirs', 'adennn', 'aeeeem',
    'aeegmu', 'aegmnn', 'afirsy', 'bjkqxz', 'ccenst',
    'ceiilt', 'ceilpt', 'ceipst', 'ddhnot', 'dhhlor',
    'dhlnor', 'dhlnor', 'eiiitt', 'emottt', 'ensssu',
    'fiprsy', 'gorrvw', 'iprrry', 'nootuw', 'ooottu'
];

let boardLetters = [];
let foundWords = [];
let score = 0;
let timer;
let timeLeft = 180; // 3 minutes
const validationCache = {};

let selectedDice = [];
let dieElements = [];

document.addEventListener('DOMContentLoaded', () => {
    // Get DOM elements
    const boardElement = document.getElementById('board');
    const boardCanvas = document.getElementById('board-canvas');
    const newGameButtons = document.querySelectorAll('.new-game-button'); // Both New Game buttons
    const submitWordButton = document.getElementById('submit-word');
    const clearSelectionButton = document.getElementById('clear-selection');
    const currentWordText = document.getElementById('current-word-text');
    const wordsList = document.querySelector('#words tbody');
    const scoreValue = document.getElementById('score-value');
    const timeDisplay = document.getElementById('time');
    const diceSound = document.getElementById('dice-sound');
    const submitSound = document.getElementById('submit-sound');
    const loadingIndicator = document.getElementById('loading');
    const messageArea = document.getElementById('message-area');
    const messageText = document.getElementById('message-text');
    const messageOkButton = document.getElementById('message-ok-button');
    const shareButton = document.getElementById('share-button');

    const canvasContext = boardCanvas.getContext('2d');

    // Variables for New Game button confirmation
    let newGameConfirmation = false;
    let newGameConfirmationTimeout;

    // Event listeners for both New Game buttons
    newGameButtons.forEach(button => {
        button.addEventListener('click', handleNewGameButtonClick);
    });
    submitWordButton.addEventListener('click', submitWord);
    clearSelectionButton.addEventListener('click', clearSelection);
    messageOkButton.addEventListener('click', hideMessage);
    shareButton.addEventListener('click', shareScore);

    // Adjust canvas size on window resize
    window.addEventListener('resize', resizeCanvas);

    // Start a new game on page load or load from URL
    if (loadBoardFromURL()) {
        startTimer();
    } else {
        startNewGame();
    }

    // Function to handle New Game button clicks
    function handleNewGameButtonClick(event) {
        const button = event.currentTarget;
        if (!newGameConfirmation) {
            // First click: change button text to "Are you sure?"
            newGameButtons.forEach(btn => {
                btn.textContent = 'Are you sure?';
                btn.classList.add('confirmation');
            });
            newGameConfirmation = true;

            // Reset the button after 5 seconds if no second click
            newGameConfirmationTimeout = setTimeout(() => {
                resetNewGameButton();
            }, 5000);
        } else {
            // Second click: reset buttons and start new game
            resetNewGameButton();
            startNewGame();
        }
    }

    // Function to reset the New Game buttons
    function resetNewGameButton() {
        newGameButtons.forEach(btn => {
            btn.textContent = 'New Game';
            btn.classList.remove('confirmation');
        });
        newGameConfirmation = false;
        if (newGameConfirmationTimeout) {
            clearTimeout(newGameConfirmationTimeout);
        }
    }

    // Reset the New Game button confirmation when interacting with other elements
    function resetNewGameButtonOnAction() {
        if (newGameConfirmation) {
            resetNewGameButton();
        }
    }

    submitWordButton.addEventListener('click', resetNewGameButtonOnAction);
    clearSelectionButton.addEventListener('click', resetNewGameButtonOnAction);
    boardElement.addEventListener('click', resetNewGameButtonOnAction);

    // Function to display a message in the message area
    function showMessage(message) {
        messageText.textContent = message;
        messageArea.style.display = 'block';
    }

    // Function to hide the message area
    function hideMessage() {
        messageArea.style.display = 'none';
    }

    // Function to start a new game
    function startNewGame() {
        console.log('Starting new game');
        // Reset game state
        resetGameState();

        // Generate a new board
        generateBoard();

        // Start the timer
        startTimer();

        // Play dice roll sound
        diceSound.play();
    }

    // Function to reset game state
    function resetGameState() {
        console.log('Resetting game state');
        boardLetters = [];
        foundWords = [];
        score = 0;
        timeLeft = 180;
        scoreValue.textContent = score;
        wordsList.innerHTML = '';
        currentWordText.textContent = '';
        selectedDice = [];
        dieElements = [];
        loadingIndicator.style.display = 'none';
        clearCanvas();
        hideMessage();
        submitWordButton.disabled = false;
        clearSelectionButton.disabled = false;
        shareButton.disabled = true; // Disable share button until game ends
    }

    // Function to generate the board
    function generateBoard() {
        console.log('Generating board');
        const shuffledDice = shuffleArray([...diceConfigs]);

        // Clear the board and die elements
        boardElement.innerHTML = '';
        dieElements = [];
        boardLetters = [];

        // Roll the dice and create the board
        for (let i = 0; i < 25; i++) {
            const dieConfig = shuffledDice[i];
            const randomIndex = Math.floor(Math.random() * dieConfig.length);
            const letter = dieConfig[randomIndex].toUpperCase();

            // Handle special case for 'Qu'
            const displayLetter = (letter === 'Q') ? 'Qu' : letter;

            boardLetters.push(letter);

            // Create die element
            const dieElement = document.createElement('div');
            dieElement.classList.add('die');
            dieElement.textContent = displayLetter;

            // Store die position
            dieElement.dataset.index = i;

            // Add click event listener
            dieElement.addEventListener('click', () => {
                selectDie(i);
                resetNewGameButtonOnAction();
            });

            boardElement.appendChild(dieElement);
            dieElements.push(dieElement);
        }

        // Adjust canvas size after the board is generated
        resizeCanvas();
    }

    // Function to resize the canvas to match the board size
    function resizeCanvas() {
        const boardRect = boardElement.getBoundingClientRect();
        boardCanvas.width = boardRect.width;
        boardCanvas.height = boardRect.height;
    }

    // Function to start the game timer
    function startTimer() {
        timeDisplay.textContent = timeLeft;
        if (timer) clearInterval(timer);
        timer = setInterval(() => {
            timeLeft--;
            timeDisplay.textContent = timeLeft;
            if (timeLeft <= 0) {
                clearInterval(timer);
                endGame();
            }
        }, 1000);
    }

    // Function to handle die selection
    function selectDie(index) {
        // If the die is already selected, ignore
        if (selectedDice.includes(index)) return;

        // If it's the first die, select it
        if (selectedDice.length === 0) {
            selectedDice.push(index);
            dieElements[index].classList.add('selected');
            updateCurrentWord();
            drawLines();
        } else {
            // Check if the die is adjacent to the last selected die
            const lastIndex = selectedDice[selectedDice.length - 1];
            if (isAdjacent(lastIndex, index)) {
                selectedDice.push(index);
                dieElements[index].classList.add('selected');
                updateCurrentWord();
                drawLines();
            } else {
                // Not adjacent
                showMessage('You must select an adjacent die.');
            }
        }
    }

    // Function to check if two indices are adjacent
    function isAdjacent(index1, index2) {
        const N = 5;
        const x1 = index1 % N;
        const y1 = Math.floor(index1 / N);
        const x2 = index2 % N;
        const y2 = Math.floor(index2 / N);

        return Math.abs(x1 - x2) <= 1 && Math.abs(y1 - y2) <= 1;
    }

    // Function to update the current word display
    function updateCurrentWord() {
        let word = '';
        for (let idx of selectedDice) {
            let letter = boardLetters[idx];
            word += (letter === 'Q') ? 'QU' : letter;
        }
        currentWordText.textContent = word;
    }

    // Function to submit the word
    function submitWord() {
        let word = currentWordText.textContent.toUpperCase();

        if (!word) return;

        if (foundWords.includes(word)) {
            showMessage('You have already found that word!');
            return;
        }

        // Show loading indicator
        loadingIndicator.style.display = 'block';

        // Call isValidWord and handle the Promise
        isValidWord(word).then(isValid => {
            // Hide loading indicator
            loadingIndicator.style.display = 'none';

            if (isValid) {
                foundWords.push(word);
                const wordPoints = calculatePoints(word);
                addWordToList(word, wordPoints);
                updateScore(wordPoints);
                // Play submit word sound
                submitSound.play();
            } else {
                // Include the invalid word in the message
                showMessage(`"${word}" is not valid.`);
            }
            // Clear selection after submission
            clearSelection();
        });
    }

    // Function to clear the current selection
    function clearSelection() {
        selectedDice.forEach(idx => {
            dieElements[idx].classList.remove('selected');
        });
        selectedDice = [];
        currentWordText.textContent = '';
        clearCanvas();
    }

    // Function to add word to the list with score
    function addWordToList(word, points) {
        const row = document.createElement('tr');
        const wordCell = document.createElement('td');
        const scoreCell = document.createElement('td');

        wordCell.textContent = word;
        scoreCell.textContent = `+${points}`;

        row.appendChild(wordCell);
        row.appendChild(scoreCell);
        wordsList.appendChild(row);
    }

    // Function to update the score
    function updateScore(points) {
        score += points;
        scoreValue.textContent = score;
    }

    // Function to calculate points based on word length and 'Qu' rules
    function calculatePoints(word) {
        // Calculate the length of the word, counting 'Qu' as two letters
        let length = 0;
        for (let i = 0; i < word.length; i++) {
            if (word[i] === 'Q' && word[i + 1] === 'U') {
                length += 2;
                i++; // Skip the 'U'
            } else {
                length += 1;
            }
        }

        // Scoring based on official Boggle rules
        if (length >= 8) return 11;
        if (length === 7) return 5;
        if (length === 6) return 3;
        if (length === 5) return 2;
        if (length >= 3) return 1;
        return 0;
    }

    // Function to validate the word using the online dictionary API
    function isValidWord(word) {
        return new Promise((resolve) => {
            // First, check if the word length is sufficient
            if (word.length < 3) {
                resolve(false);
                return;
            }

            // Check if result is cached
            if (validationCache[word] !== undefined) {
                resolve(validationCache[word]);
                return;
            }

            // Fetch word validity from the online dictionary API
            fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${word.toLowerCase()}`)
                .then(response => {
                    if (response.ok) {
                        validationCache[word] = true; // Cache the result
                        resolve(true); // Word exists
                    } else {
                        validationCache[word] = false; // Cache the result
                        resolve(false); // Word does not exist
                    }
                })
                .catch(error => {
                    console.error('Error checking word:', error);
                    showMessage('Error validating word. Please try again.');
                    resolve(false);
                });
        });
    }

    // Drawing lines between selected dice
    function drawLines() {
        clearCanvas();
        if (selectedDice.length < 2) return;
        canvasContext.strokeStyle = '#004085';
        canvasContext.lineWidth = 5;
        canvasContext.beginPath();

        for (let i = 0; i < selectedDice.length; i++) {
            const idx = selectedDice[i];
            const pos = getDieCenterPosition(idx);

            if (i === 0) {
                canvasContext.moveTo(pos.x, pos.y);
            } else {
                canvasContext.lineTo(pos.x, pos.y);
            }
        }

        canvasContext.stroke();
    }

    // Function to get die center position on the canvas
    function getDieCenterPosition(index) {
        const dieElement = dieElements[index];
        const dieRect = dieElement.getBoundingClientRect();
        const boardRect = boardElement.getBoundingClientRect();

        // Calculate position relative to the board
        const x = dieRect.left - boardRect.left + dieRect.width / 2;
        const y = dieRect.top - boardRect.top + dieRect.height / 2;

        return { x: x * (boardCanvas.width / boardRect.width), y: y * (boardCanvas.height / boardRect.height) };
    }

    // Function to clear the canvas
    function clearCanvas() {
        canvasContext.clearRect(0, 0, boardCanvas.width, boardCanvas.height);
    }

    // Function to end the game
    function endGame() {
        // Disable interactions
        dieElements.forEach(die => {
            die.style.pointerEvents = 'none';
        });
        submitWordButton.disabled = true;
        clearSelectionButton.disabled = true;
        shareButton.disabled = false; // Enable share button
        showMessage(`Time's up! Your final score is ${score}.`);
    }

    // Function to share the score
    function shareScore() {
        const wordSizeCounts = {};
        foundWords.forEach(word => {
            const size = word.length;
            wordSizeCounts[size] = (wordSizeCounts[size] || 0) + 1;
        });

        const scoreData = {
            score: score,
            wordCounts: wordSizeCounts,
            board: boardLetters.join(''),
        };

        const encodedData = btoa(JSON.stringify(scoreData));

        const shareURL = `${window.location.href.split('?')[0]}?data=${encodeURIComponent(encodedData)}`;

        // Use the Web Share API if available
        if (navigator.share) {
            navigator.share({
                title: 'Check out my 5oggle score!',
                text: `I scored ${score} points in 5oggle! Can you beat my score?`,
                url: shareURL,
            })
            .then(() => console.log('Shared successfully'))
            .catch(error => console.error('Error sharing:', error));
        } else {
            // Fallback: Display the URL for manual sharing
            prompt('Copy this link to share your score:', shareURL);
        }
    }

    // Function to load the board from URL if present
    function loadBoardFromURL() {
        const urlParams = new URLSearchParams(window.location.search);
        const dataParam = urlParams.get('data');

        if (dataParam) {
            try {
                const decodedData = JSON.parse(atob(dataParam));
                if (decodedData.board) {
                    boardLetters = decodedData.board.split('');
                    generateBoardFromLetters(boardLetters);
                    score = 0;
                    scoreValue.textContent = score;
                    foundWords = [];
                    wordsList.innerHTML = '';
                    selectedDice = [];
                    dieElements = [];
                    loadingIndicator.style.display = 'none';
                    clearCanvas();
                    return true;
                }
            } catch (error) {
                console.error('Error decoding board data:', error);
            }
        }
        return false;
    }

    // Function to generate the board from given letters
    function generateBoardFromLetters(letters) {
        // Clear the board
        boardElement.innerHTML = '';
        dieElements = [];

        for (let i = 0; i < letters.length; i++) {
            const letter = letters[i];
            const displayLetter = (letter === 'Q') ? 'Qu' : letter;

            // Create die element
            const dieElement = document.createElement('div');
            dieElement.classList.add('die');
            dieElement.textContent = displayLetter;

            // Store die position
            dieElement.dataset.index = i;

            // Add click event listener
            dieElement.addEventListener('click', () => {
                selectDie(i);
                resetNewGameButtonOnAction();
            });

            boardElement.appendChild(dieElement);
            dieElements.push(dieElement);
        }

        // Adjust canvas size
        resizeCanvas();
    }

    // Utility function to shuffle an array
    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }
});